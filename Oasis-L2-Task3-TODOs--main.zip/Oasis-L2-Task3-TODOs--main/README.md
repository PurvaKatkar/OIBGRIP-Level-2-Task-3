# Oasis-L2-Task3-TODOs-
I am build TODOs app using HTML, CSS and JAVASCRIPT. it's extremely good experience with JS in this project.
